export const infoProvisionItems = [
  "설비 유해위험 물질목록",
  "공정설명서 및 공정 도면",
  "위험성평가서",
  "안전운전 및 유지관리 지침서",
  "비상대응계획",
]
